Name, SID, Email
Shih-Chieh Hsiao, 999324839, sjhsiao@ucdavis.edu
Lanqing Cheng, 914955364, lqqcheng@ucdavis.edu
Wyatt Robertson, 913920853, wcrobertson@ucdavis.edu

Creating a database:
    node createDB.js

Running the Server:
    node loginServer.js

Finding the APP on the Internet:
    http://server162.site:51577/login.html

IF already logged in:
    http://server162.site:51577/user/lango.html
    NOTE: If user tries to access http://server162.site:51577/user/lango.html without a cookie,
          user will be directed to http://server162.site:51577/login.html to login instead.

